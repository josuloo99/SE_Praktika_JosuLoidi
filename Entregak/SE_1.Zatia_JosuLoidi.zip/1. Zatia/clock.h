#ifndef CLOCK_H
#define CLOCK_H

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <pthread.h>
#include <semaphore.h> 

#include "globals.h"

void *clock_s(void *m);

#endif